from rest_framework.authentication import BasicAuthentication
from rest_framework.response import Response


# class CustomAuthentication(BasicAuthentication):

    # def authenticate(self):
        # if not super.authenticate(request):
        #     return Response({'error':'invalid username/password.'})
        request.META.get('HTTP_AUTHORIZATION')

# request factory
# session = Session()
# user_auth = HTTPBasicAuth(username=username, password=password)
# request.META['HTTP_AUTHORIZATION'] = user_auth
#
# if BasicAuthentication().authenticate(request):
# from requests import Session
# from requests.auth import HTTPBasicAuth
# from requests import Session
# from requests.auth import HTTPBasicAuth
#
# session = Session()
#
# session.auth = HTTPBasicAuth('uname', 'password')
