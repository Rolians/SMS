from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from django.conf import settings


# Create your models here.
class Department(models.Model):

    name = models.CharField(max_length=50,unique=True)

    def __str__(self):
        return self.name

class SchoolUser(AbstractUser):
    type = models.CharField(max_length=10)

# class Parent(AbstractUser):
#     student_id = models.ForeignKey(SchoolUser, on_delete=models.CASCADE)
    # bio = models.TextField(max_length=500, blank=True)
    # location = models.CharField(max_length=30, blank=True)
    # birth_date = models.DateField(null=True, blank=True)
# class Partent(models.Model):
#     student_id = models.ForeignKey(settings.AUTH_USER_MODEL)
#     address = models.CharField(max_length=50)

class Course(models.Model):
    name = models.CharField(max_length=50)
    duration = models.IntegerField()
    department_id = models.ForeignKey(Department, on_delete=models.CASCADE)

    def __str__(self):
        return self.name + " " + self.department_id.name

class Subject(models.Model):
    name = models.CharField(max_length=50)
    course_id = models.ForeignKey(Course, on_delete=models.CASCADE)
    teacher_id = models.ForeignKey(SchoolUser, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class Exam(models.Model):
    title = models.CharField(max_length=30)
    batch = models.CharField(max_length=30)
    course_id = models.ForeignKey(Course, on_delete=models.CASCADE)
    teacher_id = models.ForeignKey(SchoolUser, on_delete=models.CASCADE)

    def __str__(self):
        return self.title + " " + self.course_id.name + " (" + self.batch + " )"

class Exam_Subject(models.Model):
    marks = models.IntegerField()
    subject_id = models.ForeignKey(Subject, on_delete=models.CASCADE)
    exam_id = models.ForeignKey(Exam, on_delete=models.CASCADE)
    student_id = models.ForeignKey(SchoolUser, on_delete=models.CASCADE)
    exam_date = models.DateTimeField()

    def __str__(self):
        return self.subject_id.name + " " + self.exam_id.title


student_status_choices = (
        ('A','Absent'),
        ('P','Present'),
    )


class Attendence(models.Model):
    student_id = models.ForeignKey(SchoolUser, on_delete=models.CASCADE)
    status = models.CharField(max_length=1,choices=student_status_choices)
    remark = models.CharField(max_length=50)
    attendence_date = models.DateTimeField()
    subject_id = models.ForeignKey(Subject, on_delete=models.CASCADE)
    #course_id = models.ForeignKey(Course, on_delete=models.CASCADE)
    def __str__(self):
        return self.student_id.first_name + " " + self.student_id.last_name