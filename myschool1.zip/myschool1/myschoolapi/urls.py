from django.conf.urls import url,include
from . import views
from myschoolapi.views import DepartmentApi, CourseApi, SubjectApi , ExamApi , ExamSubjectApi, AttendenceApi

urlpatterns = [
    url(r'^deperment/$', DepartmentApi.as_view()),
    url(r'^course/$', CourseApi.as_view()),
    url(r'^subject/$', SubjectApi.as_view()),
    url(r'^exam/$', ExamApi.as_view()),
    url(r'^examsubject/$', ExamSubjectApi.as_view()),
    url(r'^login_page/$', views.LoginPage),
	url(r'^attendence/$', AttendenceApi.as_view()),    

    # url(r'^todo/$',ToDoView.as_view()),
]
