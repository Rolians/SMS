from django.apps import AppConfig


class MyschoolapiConfig(AppConfig):
    name = 'myschoolapi'
