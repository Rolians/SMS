from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render
from django.http import HttpResponse
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from myschoolapi.models import *
from django.views.decorators.csrf import csrf_exempt

# Create your views here.


# def Deparment(request):
#    text = """<h1>welcome to my app !</h1>"""
#    return HttpResponse(text)

# class Checktype(object):
#     """
#     Check the type of User
#     """
#     user = None
#
#     @staticmethod
#     def is_staff_user(username):
#         Checktype.user = SchoolUser.objects.get(username=username)
#         return Checktype.user.type.capitalize() is not 'Teacher'
#
#     @staticmethod
#     def is_super_user():
#         return Checktype.user.is_superuser()
def LoginPage(request):
        return render(request , 'student/login_new.html')

class Login(APIView):
    def post(self,request):
        username = request.data.get('username')
        password = request.data.get('password')
        print(username)
        print(password)
        user = authenticate(username=username, password=password)

        # import pdb; pdb.set_trace()
        if user is not None:
            login(request, user)
            return Response({'message':'success'}, status=status.HTTP_200_OK)

        return Response({'message': 'login failed'}, status=status.HTTP_400_BAD_REQUEST)


class DepartmentApi(APIView):
    authentication_classes = (SessionAuthentication, BasicAuthentication)
    permission_classes = (IsAuthenticated,)

    def get(self , request):
        #import pdb; pdb.set_trace()
        if not request.user.is_staff:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        if request.query_params.get('department_name'):
            query_set = Department.objects.get(
            name=request.query_params.get('department_name'))

            query_set = {
            'id': query_set.id,
            'name': query_set.name
            }
        else:
            query_set = Department.objects.all().values()

        # import pdb; pdb.set_trace()
        # request.query_params -> get request
        return Response({'result':query_set})

    def post(self, request):
        # import pdb; pdb.set_trace()
        if not request.user.is_superuser:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        d_name = request.data.get('department_name') # post request
        new_department = Department.objects.create(name=d_name)
        new_department.save()

        return Response({'message':'Opertion successful'}, status=status.HTTP_201_CREATED)

        """
        END OF DepartmentApi
        """

class CourseApi(APIView):
    authentication_classes = (SessionAuthentication, BasicAuthentication)
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        if not request.user.is_staff:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        if request.query_params.get('course_name'):
            query_set = Course.objects.get(
            name=request.query_params.get('course_name'))

            query_set = {
            'id': query_set.id,
            'name': query_set.name,
            'duration': query_set.duration
            }
        else:
            query_set = Course.objects.all().values()

        # import pdb; pdb.set_trace()
        # request.query_params -> get request
        return Response({'result':query_set})

    def post(self, request):
        if not request.user.is_superuser:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        course_name = request.data.get('course_name') # post request
        duration = request.data.get('duration')
        d_name = request.data.get('department_name') # post request

        department = Department.objects.get(name=d_name)

        new_course = Course.objects.create(name=course_name, duration=duration, department_id=department)
        new_course.save()

        return Response({'message':'Opertion successful'}, status=status.HTTP_201_CREATED)

        """
        END OF CourseApi
        """

class SubjectApi(APIView):

    authentication_classes = (SessionAuthentication, BasicAuthentication)
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        if not request.user.is_staff:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        # import pdb; pdb.set_trace()
        if request.query_params.get('subject_name'):
            query_set = Subject.objects.get(
            name=request.query_params.get('subject_name'))

            query_set = {
            'id': query_set.id,
            'name': query_set.name,
            'course_name': query_set.course_id.name
            }
        else:
            query_set = Subject.objects.all().values()

        # import pdb; pdb.set_trace()
        # request.query_params -> get request
        return Response({'result':query_set})

    def post(self, request):
        if not request.user.is_superuser:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        subject_name = request.data.get('subject_name')
        course_name = request.data.get('course_name') # post request
        t_name = request.data.get('teacher_name') # post request

        schoolUser = SchoolUser.objects.get(username=t_name)
        course = Course.objects.get(name=course_name)

        new_subject = Subject.objects.create(name=subject_name, course_id=course, teacher_id=schoolUser)
        new_subject.save()

        return Response({'message':'Opertion successful'}, status=status.HTTP_201_CREATED)

        """
        END OF SubjectApi
        """

class ExamApi(APIView):

    authentication_classes = (SessionAuthentication, BasicAuthentication)
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        if not request.user.is_staff:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        # import pdb; pdb.set_trace()
        if request.query_params.get('title'):
            query_set = Exam.objects.get(
            title=request.query_params.get('title'))

            query_set = {
            'id': query_set.id,
            'title': query_set.title,
            'batch': query_set.batch,
            'course_name' : query_set.course_id.name,
            'teacher_name' : query_set.teacher_id.username,
            }
        else:
            query_set = Exam.objects.all().values()

        # import pdb; pdb.set_trace()
        # request.query_params -> get request
        return Response({'result':query_set})

    def post(self, request):
        if not request.user.is_superuser:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        title = request.data.get('title')
        batch = request.data.get('batch')
        course_name = request.data.get('course_name') # post request
        t_name = request.data.get('teacher_name') # post request

        schoolUser = SchoolUser.objects.get(username=t_name)
        course = Course.objects.get(name=course_name)
        #import pdb; pdb.set_trace()

        new_exam = Exam.objects.create(title=title, batch=batch, teacher_id=schoolUser , course_id=course)
        new_exam.save()

        return Response({'message':'Opertion successful'}, status=status.HTTP_201_CREATED)
        """
        END OF ExamApi
        """


class ExamSubjectApi(APIView):

    authentication_classes = (SessionAuthentication, BasicAuthentication)
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        if not request.user.is_staff:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        # import pdb; pdb.set_trace()
        if request.query_params.get('subject_name'):
            subject = Subject.objects.get(name=request.query_params.get('subject_name'))
            query_set = Exam_Subject.objects.get(
            subject_id = subject)

            query_set = {
            'marks': query_set.marks,
            'subject_id': query_set.subject_id.name,
            'exam_id': query_set.exam_id.title,
            'student_id' : query_set.student_id.username,
            'exam_date' : query_set.exam_date,
            }
        else:
            query_set = Exam_Subject.objects.all().values()

        # import pdb; pdb.set_trace()
        # request.query_params -> get request
        return Response({'result':query_set})

    def post(self, request):
        if not request.user.is_superuser:
            return Response(
            {'error': 'this operation is not allowed for this user.'},
            status=status.HTTP_400_BAD_REQUEST)

        marks = request.data.get('marks')
        title = request.data.get('title')
        subject_name = request.data.get('subject_name') # post request
        s_name = request.data.get('student_name') # post request
        exam_date = request.data.get('exam_date')

        schoolUser = SchoolUser.objects.get(username=s_name)
        subject = Subject.objects.get(name=subject_name)
        title = Exam.objects.get(title=title)

        new_exam_subject = Exam_Subject.objects.create(exam_id=title, marks=marks, student_id=schoolUser , subject_id=subject , exam_date=exam_date)
        new_exam_subject.save()

        return Response({'message':'Opertion successful'}, status=status.HTTP_201_CREATED)

        """
        END OF
        """


class AttendenceApi(APIView):
        authentication_classes = (SessionAuthentication, BasicAuthentication)
        permission_classes = (IsAuthenticated,)

        def get(self, request):
            # import pdb; pdb.set_trace()
            if request.query_params.get('student_id'):
                query_sets = Attendence.objects.all().values().filter(student_id=request.query_params.get('student_id'))
                query_set=[]
                
                for c in query_sets:
                    student_id = c.get('student_id_id')
                    student = SchoolUser.objects.get(id=student_id)
                    subject_id = c.get('subject_id_id')
                    subject = Subject.objects.get(id=subject_id)
                    data = {
                        'student_id' : student_id,
                        'student_name' : student.first_name+' '+student.last_name,
                        'subject_id' : subject_id,
                        'subject_name' : subject.name,
                        'status' : c.get('status'),
                        'remark' : c.get('remark'),
                        'attendance_date' : c.get('attendence_date')
                    }
                    query_set.append(data)

            elif request.query_params.get('subject_id'):
                query_sets = Attendence.objects.all().values().filter(subject_id=request.query_params.get('subject_id'))     
                query_set=[]
                
                for c in query_sets:
                    student_id = c.get('student_id_id')
                    student = SchoolUser.objects.get(id=student_id)
                    subject_id = c.get('subject_id_id')
                    subject = Subject.objects.get(id=subject_id)
                    data = {
                        'student_id' : student_id,
                        'student_name' : student.first_name+' '+student.last_name,
                        'subject_id' : subject_id,
                        'subject_name' : subject.name,
                        'status' : c.get('status'),
                        'remark' : c.get('remark'),
                        'attendance_date' : c.get('attendence_date')
                    }
                    query_set.append(data)
            else:
                query_sets = Attendence.objects.all().values()
                query_set=[]
                
                for c in query_sets:
                    student_id = c.get('student_id_id')
                    student = SchoolUser.objects.get(id=student_id)
                    subject_id = c.get('subject_id_id')
                    subject = Subject.objects.get(id=subject_id)
                    data = {
                        'student_id' : student_id,
                        'student_name' : student.first_name+' '+student.last_name,
                        'subject_id' : subject_id,
                        'subject_name' : subject.name,
                        'status' : c.get('status'),
                        'remark' : c.get('remark'),
                        'attendance_date' : c.get('attendence_date')
                    }
                    query_set.append(data)

            # import pdb; pdb.set_trace()
            # request.query_params -> get request
            return Response({'result':query_set})
