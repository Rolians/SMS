from django.contrib import admin
from .models import Department, SchoolUser, Course, Exam, Exam_Subject, Subject, Attendence
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.contrib.admin import AdminSite
from django.utils.translation import ugettext_lazy


admin.site.site_header = 'School Management'


# Register your models here.


#     fields = ('type','username','password', 'email', 'last_name', 'first_name')

admin.site.register(Department)
admin.site.register(Course)
admin.site.register(Subject)
admin.site.register(Exam)
admin.site.register(Exam_Subject)
admin.site.register(Attendence)
#admin.site.register(Profile)


class UserCreationForm(forms.ModelForm):
    password1 = forms.CharField(label = 'Password', widget = forms.PasswordInput)
    password2 = forms.CharField(label = 'Password Confirmation', widget = forms.PasswordInput)

    class Meta:
        model = SchoolUser
        fields = ('username',)

    def clean_password2(self):
        ''' Checks that the two password entries match '''
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')

        if password1 and password2 and password1 != password2:
            raise forms.ValidationError('Passwords do NOT match!')
        return password2

    def save(self, commit = True):
        ''' Save the provided password in hashed format '''
        user = super(UserCreationForm, self).save(commit = False)
        user.set_password(self.cleaned_data['password1'])

        if commit:
            user.save()

        return user

class UserChangeForm(forms.ModelForm):
    ''' A form for updating users. Includes all the field on the user, but replaces the password field with admin's password hash display field '''
    password = ReadOnlyPasswordHashField()

    class Meta:
        model = SchoolUser
        fields = ('username', 'password', 'first_name', 'last_name', 'is_active', 'is_superuser','is_staff', 'type')

        # def clean_password(self):
        #     ''' Regardless of what the user provides, return the initial value.  This is done here rather than on the field because the field
        # does not have access to the initial value'''
        #
        #     return self.initial['password']

class UserAdmin(BaseUserAdmin):
    ''' The form to add and change user instances '''
    change_form = UserChangeForm
    add_form = UserCreationForm

    # The fields to be used in displaying the user model.
    # These override the defintions on the base UserAdmin
    # that reference specific fields on auth.User

    list_display = ('username', 'first_name', 'last_name', 'is_superuser', 'type','is_staff')
    list_filter = ('is_superuser','is_staff')

    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal Info',{'fields': ('first_name', 'last_name',)}),
        ('Permissions', {'fields': ('is_superuser','is_staff')}),

        )
    # add_fieldsets is not a standard ModelAdmin attribute.  UserAdmin
    # overrides get_fieldsets to use this attribute when creating a user

    add_fieldsets = (
        (None, {'classes': ('wide',),
            'fields': ('username', 'email', 'first_name', 'last_name', 'password1', 'password2','is_staff', 'type')}
            ),
    )

    search_fields = ('username','first_name','last_name')
    ordering = ('username',)
    filter_horizontal = ()

# Now, register the new UserAdmin...
# admin.site.unregister(SchoolUser)
admin.site.register(SchoolUser, UserAdmin)
#admin.site.register(Parent, UserAdmin)
